
import pymol
from pymol import cmd

# Start PyMOL in GUI (interactive) mode.
pymol.finish_launching()  # Launches the PyMOL GUI

# Load your receptor and ligand files
cmd.load("/Users/danib/Downloads/ligand_conformers/receptor_1_clean.pdbqt", "receptor1")
cmd.load("/Users/danib/Downloads/ligand_conformers/ligand_conformer_0095.pdbqt", "ligand")

# Set the representation styles
cmd.show("cartoon", "receptor1")
cmd.show("sticks", "ligand")
cmd.color("cyan", "receptor1")
cmd.color("yellow", "ligand")

# Optionally, adjust the view
cmd.zoom("receptor1", buffer=5)

# You can also run additional commands, for example:
cmd.orient()

# To keep the GUI open, you might want to block the Python process:
pymol.cmd.quit()  # Only when you wish to close PyMOL interactively.